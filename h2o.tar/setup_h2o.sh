#! /bin/bash
export app_domain=`kubectl -n default-tenant get ing mlrun-api -o yaml|grep app|grep -v POST|grep host|sed 's/  - host: mlrun-api.default-tenant.app.//g'`
export auth_url=`kubectl -n default-tenant get ing mlrun-api -o yaml|grep auth-url|grep -v POST|cut -f 4 -d "/"`

echo "build H2O docker image"
cd docker
docker build -t docker-registry.default-tenant.app.${app_domain}:80/iguazio/h2o .
cd -
if [ $? -ne 0 ]
then
	echo "Failed to build H2O docker image"
	exit
fi


echo "Get H2O driverless ai image"
wget https://s3.amazonaws.com/artifacts.h2o.ai/releases/ai/h2o/dai/rel-1.9.0-23/x86_64-centos7/dai-docker-centos7-x86_64-1.9.0.4-10.0.tar.gz
if [ $? -ne 0 ]
then
	echo "Failed to H2O dai image"
	exit
fi

echo "Load H2O dai image"
docker load -i ./dai-docker-centos7-x86_64-1.9.0.4-10.0.tar.gz
if [ $? -ne 0 ]
then
	echo "Failed to load H2O dai image to docker"
	exit
fi

echo "Load image to registry"
docker tag h2oai/dai-centos7-x86_64:1.9.0.4-cuda10.0.23  docker-registry.default-tenant.app.${app_domain}:80/h2oai/dai
if [ $? -ne 0 ]
then
	echo "Failed to tag H2O dai image"
	exit
fi

docker push docker-registry.default-tenant.app.${app_domain}:80/h2oai/dai
if [ $? -ne 0 ]
then
	echo "Failed to push H2O dai image"
	exit
fi


templates_dir="k8s/templates"
for template in dai-ingress.yaml  h2o-dai.yaml  h2o-ingress.yaml  h2o.yaml
do
	cat ${templates_dir}/${template} | sed s/{{auth_url}}/${auth_url}/g |\
	    sed s/{{app_domain}}/${app_domain}/g > ${template}.yaml
	kubectl apply -f ${template}.yaml
done






