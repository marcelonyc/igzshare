DOMAIN=$1
cd docker
docker build -t docker-registry.default-tenant.app.${DOMAIN}:80/iguazio/h2o .
cd -

